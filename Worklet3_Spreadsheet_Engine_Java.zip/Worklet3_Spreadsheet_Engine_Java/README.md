# Object-Oriented Spreadsheet Engine — Worklet 3 (Java)

This is a beginner-friendly, runnable Java Swing implementation of Worklet 3, based on the provided screenshots.

## Features
- Spreadsheet grid UI (Member 1)
- Save/load spreadsheet contents and formatting (Member 2)
- Bold, italic, alignment, and number formats (Member 3)
- Insert/delete rows and columns, plus formula-reference updates (Member 4)
- Integration smoke test

## Requirements
- JDK 17 or newer
- No external libraries

## Folder structure
```text
src/
  worklet3/
    api/Spreadsheet.java
    ui/SpreadsheetUI.java
    ui/ConsoleUI.java
    persistence/SheetSerializer.java
    persistence/SheetLoader.java
    formatting/CellFormat.java
    formatting/CellFormatManager.java
    structure/RowColumnManager.java
    structure/ReferenceUpdater.java
    Worklet3IntegrationTest.java
```

## Run in VS Code / terminal
Open the project folder, then run these commands from the project root:

```bash
javac -d out src/worklet3/api/Spreadsheet.java src/worklet3/formatting/CellFormat.java src/worklet3/formatting/CellFormatManager.java src/worklet3/structure/ReferenceUpdater.java src/worklet3/structure/RowColumnManager.java src/worklet3/persistence/SheetSerializer.java src/worklet3/persistence/SheetLoader.java src/worklet3/ui/ConsoleUI.java src/worklet3/ui/SpreadsheetUI.java src/worklet3/Worklet3IntegrationTest.java
java -cp out worklet3.ui.SpreadsheetUI
```

To run the integration test:
```bash
java -cp out worklet3.Worklet3IntegrationTest
```

Or compile all files at once:
```bash
javac -d out $(find src -name "*.java")
```
On Windows PowerShell, this also works:
```powershell
$files = Get-ChildItem -Recurse src -Filter *.java | ForEach-Object { $_.FullName }
javac -d out $files
java -cp out worklet3.ui.SpreadsheetUI
```

## How to use
- Double-click a cell to edit it.
- Enter a number, text, or a basic formula such as `=A1+B1` or `=A1*2`.
- Select a cell, then use the Bold / Italic / alignment / number-format controls.
- Use File > Save / Open to save and load `.sheet` files.
- Use Structure menu to insert/delete rows and columns.

## Important integration note
The included `worklet3.api.Spreadsheet` is a small self-contained shared API/demo model so this project runs without the other worklets. If your team already has Worklet 1 and Worklet 2 classes, replace this demo API with your agreed shared `Spreadsheet` API and connect the UI to your formula evaluator/recalculation service. The reference updater handles common A1-style cell references. Complex formulas/ranges and row/column deletion semantics should be connected to your Worklet 1/2 parser before final submission.
