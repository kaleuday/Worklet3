package worklet3.api;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Small shared spreadsheet model used to make Worklet 3 runnable on its own.
 * It stores raw cell input and calculates simple formulas with A1 references.
 * Connect this class to your team's Worklet 1/2 API when integrating the full project.
 */
public class Spreadsheet {
    private final Map<String, String> values = new HashMap<>();
    private int rows;
    private int columns;

    public Spreadsheet() { this(20, 10); }

    public Spreadsheet(int rows, int columns) {
        if (rows < 1 || columns < 1) throw new IllegalArgumentException("Rows and columns must be positive.");
        this.rows = rows;
        this.columns = columns;
    }

    public synchronized int getRowCount() { return rows; }
    public synchronized int getColumnCount() { return columns; }

    public synchronized String getRawValue(String address) {
        return values.getOrDefault(normalizeAddress(address), "");
    }

    public synchronized void setRawValue(String address, String value) {
        String key = normalizeAddress(address);
        values.put(key, value == null ? "" : value);
    }

    public synchronized String getDisplayValue(String address) {
        return display(normalizeAddress(address), new HashSet<>());
    }

    public synchronized Map<String, String> getAllRawValues() {
        return new HashMap<>(values);
    }

    public synchronized void replaceAll(int newRows, int newColumns, Map<String, String> newValues) {
        if (newRows < 1 || newColumns < 1) throw new IllegalArgumentException("Invalid sheet dimensions.");
        rows = newRows;
        columns = newColumns;
        values.clear();
        for (Map.Entry<String, String> e : newValues.entrySet()) {
            values.put(normalizeAddress(e.getKey()), e.getValue() == null ? "" : e.getValue());
        }
    }

    public synchronized void setDimensions(int newRows, int newColumns) {
        if (newRows < 1 || newColumns < 1) throw new IllegalArgumentException("Sheet dimensions must be positive.");
        rows = newRows;
        columns = newColumns;
    }

    private String display(String address, Set<String> visiting) {
        String raw = values.getOrDefault(address, "");
        if (!raw.startsWith("=")) return raw;
        if (!visiting.add(address)) return "#CYCLE!";
        try {
            String expression = raw.substring(1).trim();
            // This demo evaluator supports one binary operation and numeric/A1 operands.
            Matcher m = Pattern.compile("^\\s*([A-Za-z]+[0-9]+|[-+]?[0-9]*\\.?[0-9]+)\\s*([+\\-*/])\\s*([A-Za-z]+[0-9]+|[-+]?[0-9]*\\.?[0-9]+)\\s*$").matcher(expression);
            if (!m.matches()) {
                if (expression.matches("[A-Za-z]+[0-9]+")) return display(normalizeAddress(expression), visiting);
                return "#FORMULA?";
            }
            double left = operand(m.group(1), visiting);
            double right = operand(m.group(3), visiting);
            double result;
            switch (m.group(2)) {
                case "+": result = left + right; break;
                case "-": result = left - right; break;
                case "*": result = left * right; break;
                case "/":
                    if (right == 0) return "#DIV/0!";
                    result = left / right;
                    break;
                default: return "#FORMULA?";
            }
            if (!Double.isFinite(result)) return "#NUM!";
            if (result == Math.rint(result)) return Long.toString((long) result);
            return Double.toString(result);
        } catch (NumberFormatException ex) {
            return "#VALUE!";
        } finally {
            visiting.remove(address);
        }
    }

    private double operand(String token, Set<String> visiting) {
        if (token.matches("[A-Za-z]+[0-9]+")) {
            String value = display(normalizeAddress(token), visiting);
            if (value.startsWith("#")) throw new NumberFormatException("Cell contains error");
            if (value.isBlank()) return 0;
            return Double.parseDouble(value);
        }
        return Double.parseDouble(token);
    }

    public static String normalizeAddress(String address) {
        if (address == null) throw new IllegalArgumentException("Cell address cannot be null.");
        Matcher m = Pattern.compile("(?i)^([A-Z]+)([1-9][0-9]*)$").matcher(address.trim());
        if (!m.matches()) throw new IllegalArgumentException("Invalid cell address: " + address);
        return m.group(1).toUpperCase(Locale.ROOT) + Integer.parseInt(m.group(2));
    }

    public static String addressOf(int rowZeroBased, int colZeroBased) {
        if (rowZeroBased < 0 || colZeroBased < 0) throw new IllegalArgumentException("Negative row/column.");
        int n = colZeroBased + 1;
        StringBuilder col = new StringBuilder();
        while (n > 0) {
            int rem = (n - 1) % 26;
            col.insert(0, (char) ('A' + rem));
            n = (n - 1) / 26;
        }
        return col + Integer.toString(rowZeroBased + 1);
    }

    public static int columnIndex(String address) {
        String a = normalizeAddress(address);
        int n = 0;
        for (char c : a.replaceAll("[0-9]", "").toCharArray()) n = n * 26 + (c - 'A' + 1);
        return n - 1;
    }

    public static int rowIndex(String address) {
        return Integer.parseInt(normalizeAddress(address).replaceAll("[A-Z]", "")) - 1;
    }
}
