package worklet3;

import worklet3.api.Spreadsheet;
import worklet3.formatting.CellFormat;
import worklet3.formatting.CellFormatManager;
import worklet3.persistence.SheetLoader;
import worklet3.persistence.SheetSerializer;
import worklet3.structure.ReferenceUpdater;
import worklet3.structure.RowColumnManager;

import java.nio.file.Files;
import java.nio.file.Path;

/** Lightweight integration smoke test; run with java -cp out worklet3.Worklet3IntegrationTest. */
public class Worklet3IntegrationTest {
    public static void main(String[] args) throws Exception {
        Spreadsheet sheet = new Spreadsheet(5, 5);
        CellFormatManager formats = new CellFormatManager();

        sheet.setRawValue("A1", "10");
        sheet.setRawValue("B1", "5");
        sheet.setRawValue("C1", "=A1+B1");
        if (!"15".equals(sheet.getDisplayValue("C1"))) throw new AssertionError("Formula calculation failed.");

        CellFormat format = formats.getFormat("A1");
        format.setBold(true);
        format.setAlignment(CellFormat.Alignment.CENTER);
        formats.setFormat("A1", format);

        Path file = Files.createTempFile("worklet3-test", ".sheet");
        new SheetSerializer().save(sheet, formats, file);
        Spreadsheet loaded = new Spreadsheet();
        CellFormatManager loadedFormats = new CellFormatManager();
        new SheetLoader().load(loaded, loadedFormats, file);
        if (!"10".equals(loaded.getRawValue("A1"))) throw new AssertionError("Save/load value failed.");
        if (!loadedFormats.getFormat("A1").isBold()) throw new AssertionError("Save/load formatting failed.");

        ReferenceUpdater updater = new ReferenceUpdater();
        if (!"=A2+B2".equals(updater.updateForInsert("=A1+B1", 1, ReferenceUpdater.Axis.ROW))) {
            throw new AssertionError("Reference insert update failed.");
        }

        RowColumnManager manager = new RowColumnManager(loaded, loadedFormats);
        manager.insertRow(1);
        if (!"10".equals(loaded.getRawValue("A2"))) throw new AssertionError("Row insert failed.");

        Files.deleteIfExists(file);
        System.out.println("Worklet 3 integration test: ALL TESTS PASSED");
    }
}
