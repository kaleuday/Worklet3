package worklet3.structure;

import worklet3.api.Spreadsheet;
import worklet3.formatting.CellFormat;
import worklet3.formatting.CellFormatManager;
import java.util.HashMap;
import java.util.Map;

/** Insert/delete operations for rows and columns, including cell formats. */
public class RowColumnManager {
    private final Spreadsheet sheet;
    private final CellFormatManager formats;
    private final ReferenceUpdater updater = new ReferenceUpdater();

    public RowColumnManager(Spreadsheet sheet, CellFormatManager formats) {
        this.sheet = sheet;
        this.formats = formats;
    }

    public void insertRow(int rowOneBased) {
        if (rowOneBased < 1 || rowOneBased > sheet.getRowCount() + 1) throw new IllegalArgumentException("Row index out of range.");
        Map<String, String> moved = new HashMap<>();
        for (Map.Entry<String, String> e : sheet.getAllRawValues().entrySet()) {
            String address = e.getKey();
            int row = Spreadsheet.rowIndex(address) + 1;
            int col = Spreadsheet.columnIndex(address);
            if (row >= rowOneBased) row++;
            moved.put(Spreadsheet.addressOf(row - 1, col), updater.updateForInsert(e.getValue(), rowOneBased, ReferenceUpdater.Axis.ROW));
        }
        Map<String, CellFormat> movedFormats = new HashMap<>();
        formats.getAllFormats().forEach((address, format) -> {
            int row = Spreadsheet.rowIndex(address) + 1;
            int col = Spreadsheet.columnIndex(address);
            if (row >= rowOneBased) row++;
            movedFormats.put(Spreadsheet.addressOf(row - 1, col), format);
        });
        sheet.replaceAll(sheet.getRowCount() + 1, sheet.getColumnCount(), moved);
        formats.replaceAll(movedFormats);
    }

    public void deleteRow(int rowOneBased) {
        if (rowOneBased < 1 || rowOneBased > sheet.getRowCount()) throw new IllegalArgumentException("Row index out of range.");
        Map<String, String> moved = new HashMap<>();
        for (Map.Entry<String, String> e : sheet.getAllRawValues().entrySet()) {
            int row = Spreadsheet.rowIndex(e.getKey()) + 1;
            int col = Spreadsheet.columnIndex(e.getKey());
            if (row == rowOneBased) continue;
            if (row > rowOneBased) row--;
            moved.put(Spreadsheet.addressOf(row - 1, col), updater.updateForDelete(e.getValue(), rowOneBased, ReferenceUpdater.Axis.ROW));
        }
        Map<String, CellFormat> movedFormats = new HashMap<>();
        formats.getAllFormats().forEach((address, format) -> {
            int row = Spreadsheet.rowIndex(address) + 1;
            int col = Spreadsheet.columnIndex(address);
            if (row == rowOneBased) return;
            if (row > rowOneBased) row--;
            movedFormats.put(Spreadsheet.addressOf(row - 1, col), format);
        });
        sheet.replaceAll(Math.max(1, sheet.getRowCount() - 1), sheet.getColumnCount(), moved);
        formats.replaceAll(movedFormats);
    }

    public void insertColumn(int columnOneBased) {
        if (columnOneBased < 1 || columnOneBased > sheet.getColumnCount() + 1) throw new IllegalArgumentException("Column index out of range.");
        Map<String, String> moved = new HashMap<>();
        for (Map.Entry<String, String> e : sheet.getAllRawValues().entrySet()) {
            int row = Spreadsheet.rowIndex(e.getKey());
            int col = Spreadsheet.columnIndex(e.getKey()) + 1;
            if (col >= columnOneBased) col++;
            moved.put(Spreadsheet.addressOf(row, col - 1), updater.updateForInsert(e.getValue(), columnOneBased, ReferenceUpdater.Axis.COLUMN));
        }
        Map<String, CellFormat> movedFormats = new HashMap<>();
        formats.getAllFormats().forEach((address, format) -> {
            int row = Spreadsheet.rowIndex(address);
            int col = Spreadsheet.columnIndex(address) + 1;
            if (col >= columnOneBased) col++;
            movedFormats.put(Spreadsheet.addressOf(row, col - 1), format);
        });
        sheet.replaceAll(sheet.getRowCount(), sheet.getColumnCount() + 1, moved);
        formats.replaceAll(movedFormats);
    }

    public void deleteColumn(int columnOneBased) {
        if (columnOneBased < 1 || columnOneBased > sheet.getColumnCount()) throw new IllegalArgumentException("Column index out of range.");
        Map<String, String> moved = new HashMap<>();
        for (Map.Entry<String, String> e : sheet.getAllRawValues().entrySet()) {
            int row = Spreadsheet.rowIndex(e.getKey());
            int col = Spreadsheet.columnIndex(e.getKey()) + 1;
            if (col == columnOneBased) continue;
            if (col > columnOneBased) col--;
            moved.put(Spreadsheet.addressOf(row, col - 1), updater.updateForDelete(e.getValue(), columnOneBased, ReferenceUpdater.Axis.COLUMN));
        }
        Map<String, CellFormat> movedFormats = new HashMap<>();
        formats.getAllFormats().forEach((address, format) -> {
            int row = Spreadsheet.rowIndex(address);
            int col = Spreadsheet.columnIndex(address) + 1;
            if (col == columnOneBased) return;
            if (col > columnOneBased) col--;
            movedFormats.put(Spreadsheet.addressOf(row, col - 1), format);
        });
        sheet.replaceAll(sheet.getRowCount(), Math.max(1, sheet.getColumnCount() - 1), moved);
        formats.replaceAll(movedFormats);
    }
}
