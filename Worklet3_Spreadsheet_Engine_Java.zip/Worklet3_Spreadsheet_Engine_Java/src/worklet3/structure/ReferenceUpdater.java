package worklet3.structure;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Updates common A1 references after inserting/deleting rows or columns. */
public class ReferenceUpdater {
    private static final Pattern CELL_REF = Pattern.compile("(?<![A-Za-z0-9_])\\$?([A-Z]{1,3})\\$?([1-9][0-9]*)(?![A-Za-z0-9_])");

    public enum Axis { ROW, COLUMN }

    public String shiftFormulaReferences(String formula, int insertedAtOneBased, Axis axis, int offset) {
        if (formula == null || !formula.startsWith("=") || offset == 0) return formula;
        Matcher matcher = CELL_REF.matcher(formula);
        StringBuffer out = new StringBuffer();
        while (matcher.find()) {
            String colLetters = matcher.group(1);
            int row = Integer.parseInt(matcher.group(2));
            int col = columnNumber(colLetters);
            if (axis == Axis.ROW && row >= insertedAtOneBased) row += offset;
            if (axis == Axis.COLUMN && col >= columnNumberFromIndex(insertedAtOneBased)) col += offset;
            if (row < 1 || col < 1) {
                matcher.appendReplacement(out, "#REF!");
            } else {
                String replacement = columnLetters(col) + row;
                matcher.appendReplacement(out, Matcher.quoteReplacement(replacement));
            }
        }
        matcher.appendTail(out);
        return out.toString();
    }

    public String updateForInsert(String formula, int indexOneBased, Axis axis) {
        return shiftFormulaReferences(formula, indexOneBased, axis, 1);
    }

    public String updateForDelete(String formula, int indexOneBased, Axis axis) {
        if (formula == null || !formula.startsWith("=")) return formula;
        Matcher matcher = CELL_REF.matcher(formula);
        StringBuffer out = new StringBuffer();
        int deletedCol = axis == Axis.COLUMN ? columnNumberFromIndex(indexOneBased) : -1;
        while (matcher.find()) {
            int row = Integer.parseInt(matcher.group(2));
            int col = columnNumber(matcher.group(1));
            if ((axis == Axis.ROW && row == indexOneBased) || (axis == Axis.COLUMN && col == deletedCol)) {
                matcher.appendReplacement(out, "#REF!");
            } else {
                if (axis == Axis.ROW && row > indexOneBased) row--;
                if (axis == Axis.COLUMN && col > deletedCol) col--;
                matcher.appendReplacement(out, Matcher.quoteReplacement(columnLetters(col) + row));
            }
        }
        matcher.appendTail(out);
        return out.toString();
    }

    private int columnNumber(String letters) {
        int result = 0;
        for (char c : letters.toUpperCase().toCharArray()) result = result * 26 + c - 'A' + 1;
        return result;
    }
    private int columnNumberFromIndex(int zeroBasedIndex) { return zeroBasedIndex; }
    private String columnLetters(int n) {
        StringBuilder s = new StringBuilder();
        while (n > 0) {
            int rem = (n - 1) % 26;
            s.insert(0, (char) ('A' + rem));
            n = (n - 1) / 26;
        }
        return s.toString();
    }
}
