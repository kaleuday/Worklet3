package worklet3.ui;

import worklet3.api.Spreadsheet;
import java.util.Scanner;

/** Optional terminal interface for quick testing without Swing. */
public class ConsoleUI {
    public static void main(String[] args) {
        Spreadsheet sheet = new Spreadsheet(10, 6);
        Scanner scanner = new Scanner(System.in);
        System.out.println("Simple Spreadsheet Console. Example: A1=12, B1=3, C1==A1+B1, exit");
        while (true) {
            System.out.print("> ");
            String line = scanner.nextLine().trim();
            if (line.equalsIgnoreCase("exit")) break;
            int equals = line.indexOf('=');
            if (equals <= 0) {
                System.out.println("Use ADDRESS=VALUE, e.g. A1=12");
                continue;
            }
            String address = line.substring(0, equals).trim();
            String value = line.substring(equals + 1).trim();
            try {
                sheet.setRawValue(address, value);
                System.out.println(address.toUpperCase() + " = " + sheet.getDisplayValue(address));
            } catch (Exception ex) {
                System.out.println("Error: " + ex.getMessage());
            }
        }
        scanner.close();
    }
}
