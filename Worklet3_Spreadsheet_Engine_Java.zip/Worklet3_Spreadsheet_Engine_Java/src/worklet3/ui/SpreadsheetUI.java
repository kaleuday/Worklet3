package worklet3.ui;

import worklet3.api.Spreadsheet;
import worklet3.formatting.CellFormat;
import worklet3.formatting.CellFormatManager;
import worklet3.persistence.SheetLoader;
import worklet3.persistence.SheetSerializer;
import worklet3.structure.RowColumnManager;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.nio.file.Path;
import java.nio.file.Paths;

/** Swing grid UI for Worklet 3. */
public class SpreadsheetUI extends JFrame {
    private final Spreadsheet sheet = new Spreadsheet(20, 10);
    private final CellFormatManager formats = new CellFormatManager();
    private final RowColumnManager structure = new RowColumnManager(sheet, formats);
    private final SheetSerializer serializer = new SheetSerializer();
    private final SheetLoader loader = new SheetLoader();
    private final DefaultTableModel model;
    private final JTable table;

    public SpreadsheetUI() {
        super("Object-Oriented Spreadsheet Engine — Worklet 3");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1000, 620);
        setLocationRelativeTo(null);

        model = new DefaultTableModel(makeRows(), makeColumns()) {
            @Override public boolean isCellEditable(int row, int column) { return true; }
        };
        table = new JTable(model);
        table.setRowHeight(25);
        table.setCellSelectionEnabled(true);
        table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        table.setDefaultRenderer(Object.class, new FormatRenderer());
        table.getModel().addTableModelListener(e -> {
            if (e.getType() == javax.swing.event.TableModelEvent.UPDATE && e.getColumn() >= 0) {
                int r = e.getFirstRow(), c = e.getColumn();
                if (r >= 0 && r < sheet.getRowCount() && c >= 0 && c < sheet.getColumnCount()) {
                    Object input = model.getValueAt(r, c);
                    String address = Spreadsheet.addressOf(r, c);
                    sheet.setRawValue(address, input == null ? "" : input.toString());
                    refreshValues();
                }
            }
        });

        add(new JScrollPane(table), BorderLayout.CENTER);
        add(buildToolbar(), BorderLayout.NORTH);
        setJMenuBar(buildMenu());
        refreshValues();
    }

    private Object[][] makeRows() { return new Object[20][10]; }
    private String[] makeColumns() {
        String[] columns = new String[10];
        for (int c = 0; c < columns.length; c++) columns[c] = columnName(c);
        return columns;
    }
    private String columnName(int col) {
        StringBuilder s = new StringBuilder();
        int n = col + 1;
        while (n > 0) { int rem = (n - 1) % 26; s.insert(0, (char)('A' + rem)); n = (n - 1) / 26; }
        return s.toString();
    }

    private JPanel buildToolbar() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton bold = new JButton("Bold");
        JButton italic = new JButton("Italic");
        JButton left = new JButton("Left");
        JButton center = new JButton("Center");
        JButton right = new JButton("Right");
        JComboBox<CellFormat.NumberFormat> numberFormat = new JComboBox<>(CellFormat.NumberFormat.values());
        bold.addActionListener(e -> updateSelectedFormat(f -> f.setBold(!f.isBold())));
        italic.addActionListener(e -> updateSelectedFormat(f -> f.setItalic(!f.isItalic())));
        left.addActionListener(e -> updateSelectedFormat(f -> f.setAlignment(CellFormat.Alignment.LEFT)));
        center.addActionListener(e -> updateSelectedFormat(f -> f.setAlignment(CellFormat.Alignment.CENTER)));
        right.addActionListener(e -> updateSelectedFormat(f -> f.setAlignment(CellFormat.Alignment.RIGHT)));
        numberFormat.addActionListener(e -> {
            CellFormat.NumberFormat selected = (CellFormat.NumberFormat) numberFormat.getSelectedItem();
            updateSelectedFormat(f -> f.setNumberFormat(selected));
        });
        panel.add(bold); panel.add(italic); panel.add(left); panel.add(center); panel.add(right);
        panel.add(new JLabel("Number:")); panel.add(numberFormat);
        return panel;
    }

    private JMenuBar buildMenu() {
        JMenuBar bar = new JMenuBar();
        JMenu file = new JMenu("File");
        JMenuItem save = new JMenuItem("Save...");
        JMenuItem open = new JMenuItem("Open...");
        save.addActionListener(e -> saveFile());
        open.addActionListener(e -> openFile());
        file.add(save); file.add(open);

        JMenu structureMenu = new JMenu("Structure");
        addStructureItem(structureMenu, "Insert row before selected", () -> {
            int r = selectedRowOneBased(); structure.insertRow(r); rebuildGrid();
        });
        addStructureItem(structureMenu, "Delete selected row", () -> {
            int r = selectedRowOneBased(); structure.deleteRow(r); rebuildGrid();
        });
        addStructureItem(structureMenu, "Insert column before selected", () -> {
            int c = selectedColumnOneBased(); structure.insertColumn(c); rebuildGrid();
        });
        addStructureItem(structureMenu, "Delete selected column", () -> {
            int c = selectedColumnOneBased(); structure.deleteColumn(c); rebuildGrid();
        });
        bar.add(file); bar.add(structureMenu);
        return bar;
    }

    private void addStructureItem(JMenu menu, String title, Runnable action) {
        JMenuItem item = new JMenuItem(title);
        item.addActionListener(e -> {
            try { action.run(); }
            catch (Exception ex) { showError(ex.getMessage()); }
        });
        menu.add(item);
    }

    private int selectedRowOneBased() { return Math.max(1, table.getSelectedRow() + 1); }
    private int selectedColumnOneBased() { return Math.max(1, table.getSelectedColumn() + 1); }

    private interface FormatChange { void apply(CellFormat format); }
    private void updateSelectedFormat(FormatChange change) {
        int r = table.getSelectedRow(), c = table.getSelectedColumn();
        if (r < 0 || c < 0) { showError("Select a cell first."); return; }
        String address = Spreadsheet.addressOf(r, c);
        CellFormat format = formats.getFormat(address);
        change.apply(format);
        formats.setFormat(address, format);
        table.repaint();
    }

    private void refreshValues() {
        for (int r = 0; r < sheet.getRowCount() && r < model.getRowCount(); r++) {
            for (int c = 0; c < sheet.getColumnCount() && c < model.getColumnCount(); c++) {
                String address = Spreadsheet.addressOf(r, c);
                String display = sheet.getDisplayValue(address);
                Object current = model.getValueAt(r, c);
                if (current == null || !current.toString().equals(display)) {
                    model.setValueAt(display, r, c);
                }
            }
        }
        table.repaint();
    }

    private void rebuildGrid() {
        model.setRowCount(sheet.getRowCount());
        model.setColumnCount(sheet.getColumnCount());
        for (int c = 0; c < sheet.getColumnCount(); c++) model.setColumnIdentifiers(makeColumnsFor(sheet.getColumnCount()));
        refreshValues();
    }
    private String[] makeColumnsFor(int count) {
        String[] names = new String[count];
        for (int i = 0; i < count; i++) names[i] = columnName(i);
        return names;
    }

    private void saveFile() {
        JFileChooser chooser = new JFileChooser();
        if (chooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
            Path path = chooser.getSelectedFile().toPath();
            try {
                serializer.save(sheet, formats, path);
                JOptionPane.showMessageDialog(this, "Spreadsheet saved successfully.");
            } catch (Exception ex) { showError("Save failed: " + ex.getMessage()); }
        }
    }
    private void openFile() {
        JFileChooser chooser = new JFileChooser();
        if (chooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            Path path = chooser.getSelectedFile().toPath();
            try {
                loader.load(sheet, formats, path);
                rebuildGrid();
                JOptionPane.showMessageDialog(this, "Spreadsheet loaded successfully.");
            } catch (Exception ex) { showError("Load failed: " + ex.getMessage()); }
        }
    }
    private void showError(String message) {
        JOptionPane.showMessageDialog(this, message == null ? "Unknown error" : message, "Worklet 3", JOptionPane.ERROR_MESSAGE);
    }

    private class FormatRenderer extends DefaultTableCellRenderer {
        @Override public Component getTableCellRendererComponent(JTable table, Object value, boolean selected,
                                                                  boolean focus, int row, int column) {
            Component component = super.getTableCellRendererComponent(table, value, selected, focus, row, column);
            CellFormat f = formats.getFormat(Spreadsheet.addressOf(row, column));
            int style = (f.isBold() ? Font.BOLD : Font.PLAIN) | (f.isItalic() ? Font.ITALIC : Font.PLAIN);
            component.setFont(component.getFont().deriveFont(style));
            setHorizontalAlignment(switch (f.getAlignment()) {
                case CENTER -> SwingConstants.CENTER;
                case RIGHT -> SwingConstants.RIGHT;
                default -> SwingConstants.LEFT;
            });
            setText(formats.formatValue(value == null ? "" : value.toString(), f));
            return component;
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new SpreadsheetUI().setVisible(true));
    }
}
