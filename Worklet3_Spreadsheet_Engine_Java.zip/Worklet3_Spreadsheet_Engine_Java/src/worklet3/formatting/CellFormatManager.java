package worklet3.formatting;

import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Map;
import java.util.Locale;

public class CellFormatManager {
    private final Map<String, CellFormat> formats = new HashMap<>();

    public synchronized CellFormat getFormat(String address) {
        CellFormat format = formats.get(address.toUpperCase(Locale.ROOT));
        return format == null ? new CellFormat() : new CellFormat(format);
    }

    public synchronized void setFormat(String address, CellFormat format) {
        formats.put(address.toUpperCase(Locale.ROOT), new CellFormat(format));
    }

    public synchronized Map<String, CellFormat> getAllFormats() {
        Map<String, CellFormat> copy = new HashMap<>();
        formats.forEach((key, value) -> copy.put(key, new CellFormat(value)));
        return copy;
    }

    public synchronized void replaceAll(Map<String, CellFormat> newFormats) {
        formats.clear();
        newFormats.forEach(this::setFormat);
    }

    public synchronized void clear() { formats.clear(); }

    public String formatValue(String rawDisplayValue, CellFormat format) {
        if (rawDisplayValue == null || rawDisplayValue.isBlank() || rawDisplayValue.startsWith("#")) return rawDisplayValue == null ? "" : rawDisplayValue;
        try {
            double value = Double.parseDouble(rawDisplayValue);
            switch (format.getNumberFormat()) {
                case INTEGER: return Long.toString(Math.round(value));
                case DECIMAL_2: return new DecimalFormat("0.00").format(value);
                case CURRENCY: return "$" + new DecimalFormat("#,##0.00").format(value);
                case GENERAL:
                default: return rawDisplayValue;
            }
        } catch (NumberFormatException ex) {
            return rawDisplayValue;
        }
    }
}
