package worklet3.formatting;

import java.io.Serializable;

/** Formatting is stored separately from cell contents/formulas. */
public class CellFormat implements Serializable {
    private static final long serialVersionUID = 1L;

    public enum Alignment { LEFT, CENTER, RIGHT }
    public enum NumberFormat { GENERAL, INTEGER, DECIMAL_2, CURRENCY }

    private boolean bold;
    private boolean italic;
    private Alignment alignment = Alignment.LEFT;
    private NumberFormat numberFormat = NumberFormat.GENERAL;

    public CellFormat() { }

    public CellFormat(CellFormat other) {
        this.bold = other.bold;
        this.italic = other.italic;
        this.alignment = other.alignment;
        this.numberFormat = other.numberFormat;
    }

    public boolean isBold() { return bold; }
    public void setBold(boolean bold) { this.bold = bold; }
    public boolean isItalic() { return italic; }
    public void setItalic(boolean italic) { this.italic = italic; }
    public Alignment getAlignment() { return alignment; }
    public void setAlignment(Alignment alignment) {
        this.alignment = alignment == null ? Alignment.LEFT : alignment;
    }
    public NumberFormat getNumberFormat() { return numberFormat; }
    public void setNumberFormat(NumberFormat numberFormat) {
        this.numberFormat = numberFormat == null ? NumberFormat.GENERAL : numberFormat;
    }
}
