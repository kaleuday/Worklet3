package worklet3.persistence;

import worklet3.api.Spreadsheet;
import worklet3.formatting.CellFormat;
import worklet3.formatting.CellFormatManager;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.Base64;
import java.util.Map;

/** Writes sheet values and formatting to a simple versioned text format. */
public class SheetSerializer {
    public void save(Spreadsheet sheet, CellFormatManager formats, Path path) throws IOException {
        try (BufferedWriter writer = Files.newBufferedWriter(path, StandardCharsets.UTF_8)) {
            writer.write("WORKLET3_SHEET_V1"); writer.newLine();
            writer.write("ROWS\t" + sheet.getRowCount()); writer.newLine();
            writer.write("COLS\t" + sheet.getColumnCount()); writer.newLine();
            for (Map.Entry<String, String> e : sheet.getAllRawValues().entrySet()) {
                writer.write("CELL\t" + e.getKey() + "\t" + encode(e.getValue())); writer.newLine();
            }
            for (Map.Entry<String, CellFormat> e : formats.getAllFormats().entrySet()) {
                CellFormat f = e.getValue();
                writer.write("FORMAT\t" + e.getKey() + "\t" + f.isBold() + "\t" + f.isItalic()
                        + "\t" + f.getAlignment().name() + "\t" + f.getNumberFormat().name());
                writer.newLine();
            }
        }
    }
    private String encode(String value) {
        return Base64.getEncoder().encodeToString(value.getBytes(StandardCharsets.UTF_8));
    }
}
