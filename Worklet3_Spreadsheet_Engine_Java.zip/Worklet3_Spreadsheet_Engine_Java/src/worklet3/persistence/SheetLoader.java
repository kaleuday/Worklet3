package worklet3.persistence;

import worklet3.api.Spreadsheet;
import worklet3.formatting.CellFormat;
import worklet3.formatting.CellFormatManager;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

/** Loads and validates files created by SheetSerializer. */
public class SheetLoader {
    public void load(Spreadsheet sheet, CellFormatManager formats, Path path) throws IOException {
        int rows = -1, cols = -1;
        Map<String, String> values = new HashMap<>();
        Map<String, CellFormat> loadedFormats = new HashMap<>();
        try (BufferedReader reader = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
            String header = reader.readLine();
            if (!"WORKLET3_SHEET_V1".equals(header)) throw new IOException("Not a supported Worklet 3 sheet file.");
            String line;
            while ((line = reader.readLine()) != null) {
                String[] p = line.split("\\t", -1);
                try {
                    switch (p[0]) {
                        case "ROWS": rows = Integer.parseInt(p[1]); break;
                        case "COLS": cols = Integer.parseInt(p[1]); break;
                        case "CELL":
                            if (p.length != 3) throw new IOException("Invalid CELL record.");
                            values.put(Spreadsheet.normalizeAddress(p[1]), new String(Base64.getDecoder().decode(p[2]), StandardCharsets.UTF_8));
                            break;
                        case "FORMAT":
                            if (p.length != 6) throw new IOException("Invalid FORMAT record.");
                            CellFormat f = new CellFormat();
                            f.setBold(Boolean.parseBoolean(p[2]));
                            f.setItalic(Boolean.parseBoolean(p[3]));
                            f.setAlignment(CellFormat.Alignment.valueOf(p[4]));
                            f.setNumberFormat(CellFormat.NumberFormat.valueOf(p[5]));
                            loadedFormats.put(Spreadsheet.normalizeAddress(p[1]), f);
                            break;
                        default: throw new IOException("Unknown record: " + p[0]);
                    }
                } catch (RuntimeException ex) {
                    throw new IOException("Invalid data in sheet file: " + line, ex);
                }
            }
        }
        if (rows < 1 || cols < 1) throw new IOException("Missing or invalid sheet dimensions.");
        sheet.replaceAll(rows, cols, values);
        formats.replaceAll(loadedFormats);
    }
}
